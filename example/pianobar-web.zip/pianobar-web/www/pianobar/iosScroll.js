 var startY = 0;

  function checkObj(e){
    if( !e ){
      return true;
    }
    if( e.tagName.toLowerCase() == "body" || e.tagName.toLowerCase() == "html" ){
      return true;
    }else if( e.className.toLowerCase() == "scrollable" ){
      return false;
    }
    return checkObj( e.parentNode );
  };
  
  function scrollHandler(e){
    var curY = e.touches[0].pageY;
    
    var pbList = document.getElementById( 'pblist' );
    
    if( pbList ){

      var divPos = pbList.scrollTop;
      var maxScroll = pbList.scrollHeight;
      maxScroll = maxScroll - pbList.clientHeight;
    
      if( curY > startY ){
        //scrolling up
        if( divPos == 0 ){
          e.preventDefault();
          return;
        }
      }else if( curY < startY ){
        //scrolling down
        if( divPos == maxScroll ){
          e.preventDefault();
          return;
        }
      }
      
    
      if( checkObj( e.target ) ){
        //we've determined that we should prevent scrolling
        e.preventDefault();
      }
    }else{
      //If we don't have a pblist element, we are on the index page.
      //no scrolling at all
      e.preventDefault();
    }
  };
  
  
  function onTouchStart( e ){
    startY = e.touches[0].pageY;
  };
  
  document.addEventListener('touchmove', scrollHandler );
  document.addEventListener( 'touchstart', onTouchStart );