1.  Apply steve.patch to pianobar source.
2.  Modify ~/.config/pianobar/config to match mine
3.  Create ~/.config/pianobar/ctl as a fifo (http://linux.die.net/man/3/mkfifo)
4.  Install node.js
5.  add socket.io to node.js   ( http://socket.io/#how-to-use )
6.  put the node folder somewhere convenient.
7.  launch the node server with "node <app.js>"
	This server will listen on a port spec'd in app.js (i setup 8000)
	Make sure this is forwarded through your router.
	(There are some instructions on how to setup apache reverse proxies, but these don't seem to work with socket.io's long polling methods)
8.  put the www folder in your webroot
9.  grant write permissions to pb.html, pblist.html. and pblist.txt for the user running pianobar
10. Start pianobar
11. point web browser at /pianobar/pianobar.php.  you should have control, and get proper currently playing info.


Feel free to play with my setup at thestobor.net/pianobar/pianobar.php